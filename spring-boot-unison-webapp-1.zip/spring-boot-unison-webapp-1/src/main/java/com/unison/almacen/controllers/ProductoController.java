package com.unison.almacen.controllers;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.time.LocalDate;
import java.util.List;
import com.unison.almacen.exception.NotFoundException;
import com.unison.modelos.Producto;
import jakarta.validation.Valid;
import lombok.NoArgsConstructor;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.unison.almacen.repository.ProductoRepository;

@Controller
@RequestMapping("/productos")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@NoArgsConstructor
public class ProductoController {

	private ProductoRepository productoRepository;

	@GetMapping
	public String listado(Model modelo) {
		List<Producto> productos = productoRepository.findAll().stream().toList();
		modelo.addAttribute("productos", productos);
		return "productos/productosView";
	}

	@PostMapping("/guardar")
	public String guardarProducto(@Valid @ModelAttribute Producto producto, BindingResult result, Model modelo) {

		if(result.hasErrors()) {
			modelo.addAttribute("producto", producto);
			return "productos/productosRegistro";
		}

		// Asignar la fecha actual al campo fechaRegistro
		if (producto.getFechaRegistro() == null) {
			producto.setFechaRegistro(LocalDate.now());  // Asigna la fecha actual
		}

		// Guardar el producto en la base de datos
		productoRepository.save(producto);

		return "redirect:/productos";
	}

	@GetMapping("/agregar")
	public String agregarFormulario(Model modelo) {
		modelo.addAttribute("producto", new Producto());
		return "productos/productosRegistro";
	}

	@Autowired
	public ProductoController(ProductoRepository productoRepository) {
		this.productoRepository = productoRepository;
	}

	@GetMapping("/listar") // Read - Regresa algo
	public List<Producto> listar() {
		return productoRepository.findAll().stream().toList();
	}

	// Mostrar el formulario de modificación
	@GetMapping("/modificar/{id}")
	public String mostrarFormularioDeModificacion(@PathVariable Long id, Model model) {
		// Buscar el producto por su id
		Producto producto = productoRepository.findById(id).orElseThrow(NotFoundException::new);

		// Agregar el producto al modelo para que Thymeleaf lo muestre en el formulario
		model.addAttribute("producto", producto);

		return "productos/productosModificar"; // Nombre de la vista HTML para modificar producto
	}

	// Procesar la actualización del producto
	@PostMapping("/modificar/{id}")
	public String modificarProducto(@PathVariable Long id, @ModelAttribute Producto productoDetalles) {
		// Buscar el producto original
		Producto producto = productoRepository.findById(id).orElseThrow(NotFoundException::new);

		// Actualizar los campos del producto con los nuevos detalles
		producto.setNombre(productoDetalles.getNombre());
		producto.setPrecio(productoDetalles.getPrecio());
		producto.setDescripcion(productoDetalles.getDescripcion());
		producto.setFechaRegistro(LocalDate.now());

		// Guardar los cambios
		productoRepository.save(producto);

		// Redirigir a la lista de productos después de modificar
		return "redirect:/productos";
	}

	@PostMapping("/eliminar/{id}")
	public String eliminar(@PathVariable Long id) {
		if (productoRepository.existsById(id)) {
			productoRepository.deleteById(id);
		}
		return "redirect:/productos"; // Redirige a la lista de productos
	}

	@GetMapping("/exportarExcel")
	public ResponseEntity<byte[]> exportarAExcel() {
		List<Producto> productos = productoRepository.findAll();

		// Crear un libro de trabajo de Excel
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Productos");

		// Crear la primera fila para los encabezados
		Row headerRow = sheet.createRow(0);
		String[] columnHeaders = {"ID", "Nombre", "Precio", "Descripción", "Fecha de Registro"};
		for (int i = 0; i < columnHeaders.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columnHeaders[i]);
		}

		// Agregar los datos de los productos a las filas
		int rowNum = 1;
		for (Producto producto : productos) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(producto.getId());
			row.createCell(1).setCellValue(producto.getNombre());
			row.createCell(2).setCellValue(producto.getPrecio());
			row.createCell(3).setCellValue(producto.getDescripcion());
			row.createCell(4).setCellValue(producto.getFechaRegistro().toString());
		}

		// Convertir el libro de trabajo a un array de bytes
		try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
			workbook.write(byteArrayOutputStream);
			byte[] excelFile = byteArrayOutputStream.toByteArray();

			// Establecer el encabezado para descargar el archivo Excel
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "attachment; filename=productos.xlsx");

			// Retornar el archivo Excel como una respuesta
			return ResponseEntity.ok()
					.headers(headers)
					.body(excelFile);
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(500).body(null);
		}
	}
}

