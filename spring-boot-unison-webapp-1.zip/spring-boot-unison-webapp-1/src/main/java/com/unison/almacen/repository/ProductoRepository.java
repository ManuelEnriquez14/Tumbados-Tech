package com.unison.almacen.repository;


import com.unison.modelos.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductoRepository extends JpaRepository<Producto,Long>{

    Producto findById(long id);

}
