package com.unison.almacen;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import com.unison.almacen.exception.NotFoundException;
@SpringBootApplication
@EntityScan("com.unison.modelos")
public class SpringBootUnisonWebapp1Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootUnisonWebapp1Application.class, args);

    }

}

