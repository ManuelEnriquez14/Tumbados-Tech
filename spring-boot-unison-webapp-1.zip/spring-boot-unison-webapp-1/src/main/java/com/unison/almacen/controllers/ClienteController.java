package com.unison.almacen.controllers;

import com.unison.almacen.exception.NotFoundException;
import com.unison.modelos.Cliente;
import com.unison.modelos.Producto;
import jakarta.validation.Valid;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.unison.almacen.repository.ClienteRepository;
import java.util.List;

@Controller
@RequestMapping("/clientes")
@CrossOrigin(origins = "*",allowedHeaders = "*")
@NoArgsConstructor
public class ClienteController {

    private ClienteRepository clienteRepository;

    @GetMapping
    public String listado(Model modelo) {
        List<Cliente> clientes = clienteRepository.findAll().stream().toList();
        modelo.addAttribute("clientes", clientes);
        return "clientes/clientesView";
    }

    @PostMapping("/guardar")
    public String guardarCliente(@Valid @ModelAttribute Cliente cliente, BindingResult result, Model modelo) {

        if (result.hasErrors()) {
            modelo.addAttribute("cliente", cliente);
            return "clientes/clientesRegistro";
        }

        clienteRepository.save(cliente);
        return "redirect:/clientes";
    }

    @GetMapping("/agregar")
    public String agregarFormulario(Model modelo) {
        modelo.addAttribute("cliente", new Cliente());
        return "clientes/clientesRegistro";
    }

    @Autowired
    public ClienteController(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    @GetMapping("/listar") // Read - Regresa algo
    public List<Cliente> listar() {
        return clienteRepository.findAll().stream().toList();
    }

    @PutMapping("/modificar/{id}") //Update - Actualiza algo.
    public ResponseEntity<?> modificar (@PathVariable("id") Long id, @RequestBody Cliente clienteDetalles){

        // Buscar el producto
        Cliente cliente  = clienteRepository.findById(id).orElseThrow(NotFoundException::new);

        // Actualizar los datos del cliente
        cliente.setNombreUsuario(clienteDetalles.getNombreUsuario());
        cliente.setPassword(clienteDetalles.getPassword());

        // Guardar los cambios.
        Cliente clienteActualizado = clienteRepository.save(cliente);

        // Terminar el proceso.
        return ResponseEntity.ok(clienteActualizado);
    }

    @DeleteMapping("/eliminar/{id}") //Delete - Elimina algo
    public ResponseEntity<?> eliminar(@PathVariable("id") Long id){

        // Eliminar el producto
        clienteRepository.deleteById(id);

        // Terminar proceso
        return ResponseEntity.ok("Se eliminó el cliente.");
    }
}
